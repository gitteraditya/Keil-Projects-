#include <reg51.h>
sbit r1=P1^0;
sbit r2=P1^1;
sbit r3=P1^2;
sbit r4=P1^3;
sbit c1=P1^4;
sbit c2=P1^5;
sbit c3=P1^6;
//keypad
sbit rs=P3^0;
sbit rw=P3^1;
sbit en=P3^2;
sfr lcd=0xa0;
void delay();
void lcdcmd(unsigned char);
void lcddata(unsigned char);
void main()
{
    P2=0x00;
  	//.4,.5=4d ,e and 3.7 3.3,*,c,g
    lcdcmd(0x38);
	delay();
    lcdcmd(0x01);
	delay();
    lcdcmd(0x06);
	delay();
    lcdcmd(0x0c);
	delay();
    lcdcmd(0x81);
	delay();
    while(1)
    {
        r1=0;
        if(c1==0)
        {
            lcddata('1');
            delay();
        }
        if(c2==0)
        {
            lcddata('2');
            delay();
        }
         if(c3==0)
        {
            lcddata('3');
            delay();
        }
        r1=1;r2=0;
        if(c1==0)
        {
            lcddata('4');
            delay();
        }
        if(c2==0)
        {
            lcddata('5');
            delay();
        }
         if(c3==0)
        {
            lcddata('6');
            delay();
        }
        r2=1;r3=0;
        if(c1==0)
        {
            lcddata('7');
            delay();
        }
        if(c2==0)
        {
            lcddata('8');
            delay();
        }
         if(c3==0)
        {
            lcddata('9');
            delay();
        }
        r3=1;r4=0;
        if(c1==0)
        {
            lcddata('*');
            delay();
        }
        if(c2==0)
        {
            lcddata('0');
            delay();
        }
         if(c3==0)
        {
            lcddata('#');
            delay();
        }
    }
}
void delay()
{
  unsigned int i;
	unsigned int j;
	unsigned int k=0;
	for(i=0;i<100;i++)
	{
	  for(j=0;j<400;j++)
		{
	    k=k+1;
		}k=0;
	}k=0;
}
void lcdcmd(unsigned char val)
{
P2 = val;
rs=0;//Command Register
rw=0;//(write)
en=1;
delay();
//used by the LCD to latch
//information presented to
//its data bus
en=0;
}
void lcddata(unsigned char val)
{
P2 =val;
rs=1;//Data Register Selection
rw=0;//(write)
en=1;
delay();
en=0;
}
