#include <reg51.h>
void delay (unsigned int);
sbit motor = P2^0;
sbit sw1 = P1^0;//low Speed
sbit sw2 = P1^1;//Average Speed
sbit sw3 = P1^2;//Max Speed
sbit sw4 = P1^3;//To stop Motor
void main()
{
   while(1)
	 {
	    if(sw1==0) //Switch 1
			{
			  motor=1;
				delay(10);
				motor=0;
				delay(10);
			}
			else if(sw2==0)//Switch 2
			{
				motor=1;
				delay(20);
				motor=0;
				delay(5);
			}
			else if(sw3==0)//Switch 3
			{
			  motor=1;
			}
			else if(sw4==0)//Switch 4
			{
			  motor=0;
			}
	 }
}
void delay (unsigned int val) //Time Delay
{
	 unsigned int i;
	 unsigned int j;
   for(i=0;i<val;i++);
	 for(j=0;j<4000;j++);
}
