#include <reg51.h>
void delay(unsigned int);// [ 0 5 : 60 ] = Clock  [][][][] so 4 BCDS
void main()
{
unsigned char seg[10] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};//Array consisting 0-9 Digit.
unsigned int i;
unsigned int m;
unsigned int j;
  while(1)
  {
  P0 = 0x00;
	P1 = 0x00;
	P2 = 0x00;
	P3 = 0x00;//It will remain 0 for infinite time.
	//4 Seven Segments to be taken
	delay(250);
	P3 = P2 = P1 = P0 =0xc0;
	for(m=1;m<=5;m++)//it is the 5 minutes clock
		{
		   for(i=0;i<=5;i++)//P1 it will run till 5 because there are 60 seconds in 1 minute
			{
			   for(j=0;j<=9;j++)//P0 it will from 9
				{
				  P0=seg[j];
					P1=seg[i];
					P2=seg[m];
					delay(500);
				}
			}
		}
  }
}
void delay (unsigned int x) //Time Delay Creation
{
   unsigned int p;
   unsigned int q;
   unsigned int o=0;
   for(p=0;p<500;p++)
   {
      for(q=0;q<x;q++)
	  {
	     o = o+1;
	  }
		o=0;
   }
}
