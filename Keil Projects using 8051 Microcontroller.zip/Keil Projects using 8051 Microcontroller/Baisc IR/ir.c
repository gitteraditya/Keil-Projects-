#include < reg51.h>
sbit ir = P1^0;
sbit led = P1^6;
void main()
{
while(1)
{
  if(ir==1)
  {
    led=1;
  }
  else
  {
    led=0;
  }
}
}
