#include <reg51.h>
void delay(unsigned int);// [ MINUTE : SECONDS ] = Clock  [M0][M1][S0][S1] so 4 BCDS
sbit a=P1^0;
sbit b=P1^1;
sbit c=P1^2;
sbit d=P1^3;
void main()
{
unsigned int i;
a=b=c=d=0;
P2 = 0x00;
  while(1)
  {
		    //Simply to print a [ 5009 ]
				d=1;
				P2=0x90;
		    for(i=0;i<20;i++);
				d=0;
				c=1;
		    P2=0xc0;
		    for(i=0;i<20;i++);
				c=0;
				b=1;
				P2=0xc0;
		    for(i=0;i<20;i++);
				b=0;
				a=1;
				P2=0x92;
		    for(i=0;i<20;i++);
		    a=0;
  }
}
void delay (unsigned int x)
{
   unsigned int p;
   unsigned int q;
   unsigned int o=0;
   for(p=0;p<500;p++)
   {
      for(q=0;q<x;q++)
	  {
	     o = o+1;
	  }
		o=0;
   }
}
